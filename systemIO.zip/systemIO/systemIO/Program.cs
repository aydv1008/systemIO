﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace systemIO
{
    class Program
    {
        static void Main(string[] args)
        {
            employee emp = new employee();
            string employee = @"C:\Users\Pooja Rani\Desktop\myfile.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(employee,true))
                {

                    writer.WriteLine(emp.displayemp() + "\n");
                }
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }

            department dep = new department();
            string department = @"C:\Users\Pooja Rani\Desktop\myfile1.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(department, true))
                {

                    writer.WriteLine(dep.displaydep() + "\n");
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
            projects pro = new projects();
            string projects = @"C:\Users\Pooja Rani\Desktop\myfile2.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(projects, true))
                {

                    writer.WriteLine(dep.displaydep() + "\n");
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
